import java.util.Scanner;

public class countSak {


//    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//
//        System.out.println("Enter your number from range (-1;1) ");
//        double xPar = sc.nextDouble();
//        System.out.println("Enter your precision");
//        double precPar = sc.nextDouble();
//        double sum = 0;
//        double firstCnt = 0, secondCnt = 0, res = 0;
//
//        for (int i = 1; Math.pow(xPar, 3*(Math.pow(i,2))) >= precPar; ++i){
//            sum += Math.pow(xPar, 3*(Math.pow(i,2)));
//        }
//
//        for (int j = 1; Math.pow(xPar, 3*(Math.pow(j,2))) >= precPar; ++j){
//            secondCnt = Math.pow(xPar, (6*j + 3));
//        }
//
//        System.out.println(sum);
//
//    }


    public static void main(String[] args) {
        try {
            if (args.length != 2)
                throw new IllegalArgumentException();
            try {
                double res = calcPrev(Double.parseDouble(args[0]), Double.parseDouble(args[1]));
                System.out.println(res);
            } catch (NumberFormatException e) {
                System.out.println("Incorrect input");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Incorrect input");
        }
    }
    private static double calcPrev(double xPar, double precPar){
        double prevDef = Math.pow(xPar, 3);
        System.out.println(prevDef);
        return prevDef + calcCur(xPar,  precPar, 1, prevDef);
    }

    private static double calcCur(double xPar, double precPar, int i, double prevDef){
        if (Math.abs(prevDef) < precPar){
            return 0;
        }
        double curDef = prevDef*Math.pow(xPar,(6*i)+3);
        System.out.println(curDef);
        return curDef + calcCur(xPar, precPar, i+1, curDef);
    }
}
