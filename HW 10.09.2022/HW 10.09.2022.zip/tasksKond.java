import java.math.BigInteger;
import java.util.Scanner;

public class tasksKond {
    public static void main(String[] args){

//        numberToOther1();
//        angleTrans2();
//        findMax3();
//        showMinMax4();
//        tryRetype5();
//        factCalc6();

    }

    static void numberToOther1(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your number:");
        int num = sc.nextInt();
        System.out.println("Number in binary system:" + Integer.toBinaryString(num));
        System.out.println("Number in octal system:" + Integer.toOctalString(num));
        System.out.println("Number in hexal system:" + Integer.toHexString(num));
    }
    static void angleTrans2(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your angle:");
        double num = sc.nextDouble();
        System.out.println("Your angle in deegrees:" + ( Math.round((Math.abs(num)*180)/Math.PI)) );
    }
    static void findMax3(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three numbers");
        double firNum = sc.nextDouble();
        double secNum = sc.nextDouble();
        double thirNum = sc.nextDouble();
        if(Math.min(firNum, secNum) > thirNum){
            System.out.println("Max number from three = " + Math.max(firNum, secNum));
        }
        else if (Math.min(firNum, thirNum) > secNum){
            System.out.println("Max number from three = " + Math.max(firNum, thirNum));
        }
        else if(Math.min(secNum, thirNum) > firNum){
            System.out.println("Max number from three = " + Math.max(secNum, thirNum));
        }
        else{
            System.out.println("Max number from three = " + firNum);
        }
    }
    static void showMinMax4(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your double ");
        double num = sc.nextDouble();
        System.out.println("Maximum definition of that double = " + Math.nextUp(num));
        System.out.println("Minimum definition of that double = " + Math.nextDown(num));
    }
    static void tryRetype5(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your double ");
        double num = sc.nextDouble();
        System.out.println("Your int = " + (int)num );
    }
    static void factCalc6(){
        BigInteger num = BigInteger.ONE;
        for (int i = 1; i < 1001; ++i){
            num = num.multiply(BigInteger.valueOf(i));
        }
        System.out.println("Your answer: " + num);
    }
}
