public class Main {
    public static void main(String[] args) {
//        MainFrameForFirstTask a = new MainFrameForFirstTask();
//        a.setVisible(true);

        MainFrameForSecondTask b = new MainFrameForSecondTask();
        b.setVisible(true);
    }
}
