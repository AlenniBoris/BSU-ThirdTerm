import Lab7.FrameClass;
import Lab8.FirstTask;
import Lab8.SecondTask;
import Lab8.ThirdTask;

public class MainClass {
    public static void main(String[] args) {
//        Lab8.FirstTask lab8First = new FirstTask();
//        Lab8.SecondTask lab8Second = new SecondTask();
        Lab8.ThirdTask lab8Third = new ThirdTask();

//        Lab7.FrameClass frameClass = new FrameClass();
    }

}
